
public interface Supermarkt {

	public String getDescription();

	public double getRevenue();


}
