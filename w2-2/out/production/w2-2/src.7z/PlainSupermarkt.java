
public class PlainSupermarkt implements Supermarkt {

	@Override
	public String getDescription() {
		//TODO auto-generated method stub
		return "Basic";
	}

	@Override
	public double getRevenue() {
		// TODO auto-generated method stub
		return 4.00;
	}


}
